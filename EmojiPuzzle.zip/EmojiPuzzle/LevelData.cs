using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

[Serializable]
public class NodeData
{
    public Sprite Spr;
    public int MatchId;
}

public enum GameType
{
    Match2, DragShadow
}

[CreateAssetMenu(fileName = "LevelData", menuName = "Level/LevelData")]
public class LevelData : ScriptableObject
{
    [SerializeField] private GameType _gameType;
    [SerializeField] private List<NodeData> _nodeData;

    public GameType GameType => _gameType;
    public List<NodeData> NodeData => _nodeData;
}


