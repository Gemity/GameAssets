using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class DragShadowGame : MonoBehaviour, IMiniGame
{
    [SerializeField] private List<DisplayNode> _displayNodes;
    [SerializeField] private List<ShadowNode> _shadowNodes;

    private DisplayNode _currentDragNode;
    private Camera _cam;
    public Action onWin { get; set; }
    public Action onLose { get; set; }

    public void Init(LevelData lvData)
    {
        for(int i = 0; i < _displayNodes.Count; i++)
        {
            _displayNodes[i].Setup(lvData.NodeData[i]);
            _displayNodes[i].onClick += OnClick;
        }

        for (int i = 0; i < _shadowNodes.Count; i++)
        {
            _shadowNodes[i].Setup(lvData.NodeData[i]);
        }

        _cam = Camera.main;
    }

    public bool CheckWin()
    {
        foreach(var node in _displayNodes)
        {
            if (!node.IsCorrect)
                return false;
        }

        return true;
    }

    public void Win()
    {
        onWin?.Invoke();
    }

    public void Lose()
    {
        onLose?.Invoke();
    }

    private void OnClick(DisplayNode node)
    {
        if(_currentDragNode == null)
        {
            _currentDragNode = node;
        }
    }

    private void Update()
    {
        if (_currentDragNode == null)
            return;

        Vector3 worldPos = _cam.ScreenToWorldPoint(Input.mousePosition);
        worldPos = new Vector3(worldPos.x, worldPos.y, 0);
        _currentDragNode.transform.position = worldPos;

        if (Input.GetMouseButtonUp(0))
        {
            if (CheckDropCorrect(out ShadowNode node))
            {
                _currentDragNode.Correct(node);
                if (CheckWin())
                    Win();
            }
            else
                _currentDragNode.Wrong();

            _currentDragNode = null;
        }
    }

    private bool CheckDropCorrect(out ShadowNode node)
    {
        node = null;
        foreach(var shadow in _shadowNodes)
        {
            if (shadow.InsideShadow(_currentDragNode.Id, _currentDragNode.transform.position))
            {
                node = shadow;
                return true;
            }
        }

        return false;
    }
}
