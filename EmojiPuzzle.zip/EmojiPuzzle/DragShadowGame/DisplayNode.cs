using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class DisplayNode : MonoBehaviour
{
    [SerializeField] private SpriteRenderer _spr;
    [SerializeField] private BoxCollider2D _box;

    private Vector3 _originPos;
    private int _id;
    private bool _isCorrect;

    public int Id => _id;

    public bool IsCorrect => _isCorrect;

    public Action<DisplayNode> onClick;

    public void Setup(NodeData data)
    {
        _spr.sprite = data.Spr;
        _id = data.MatchId;
        _originPos = transform.position;
        _isCorrect = false;
    }

    private void OnMouseDown()
    {
        onClick?.Invoke(this);
    }

    public void Correct(ShadowNode node)
    {
        _isCorrect = true;
        _box.enabled = false;
        transform.position = node.transform.position;
    }

    public void Wrong()
    {
        transform.position = _originPos;
    }
}
