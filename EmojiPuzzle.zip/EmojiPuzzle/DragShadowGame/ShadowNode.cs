using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShadowNode : MonoBehaviour
{
    [SerializeField] private SpriteRenderer _spr;
    [SerializeField] private float _threshold;

    private int _id;
    public int Id => _id;

    public void Setup(NodeData data)
    {
        _spr.sprite = data.Spr;
        _id = data.MatchId;
    }

    public bool InsideShadow(int id, Vector3 pos)
    {
        bool correctId = id == _id;
        bool distance = Vector3.Distance(pos, transform.position) < _threshold;
        return correctId && distance;
    }
}
