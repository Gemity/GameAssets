using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
public interface IMiniGame
{
    Action onWin { get; set; }
    Action onLose { get; set; }

    void Init(LevelData lvData);
    void Win();
    void Lose();
    bool CheckWin();
}
