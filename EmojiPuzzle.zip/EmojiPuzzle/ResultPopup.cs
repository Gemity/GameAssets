using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using DG.Tweening;
using UnityEngine.SceneManagement;

public class ResultPopup : MonoBehaviour
{
    [SerializeField] private Image _slide;
    [SerializeField] private TMP_Text _percentText;
    [SerializeField] private float _duration;
    [SerializeField] private GameObject _doneBtn;

    private IEnumerator Start()
    {
        float start = 0;
        float end = 1;

        float timer = 0;
        float delta = (end - start) / _duration;
        _slide.fillAmount = start;

        while(timer < _duration)
        {
            _slide.fillAmount += delta * Time.deltaTime;
            timer += Time.deltaTime;
            int percent = (int)(_slide.fillAmount * 100f);
            _percentText.text = $"{percent}%";
            yield return null;
        }

        _doneBtn.SetActive(true);
    }

    public void ClickDone()
    {
        SceneManager.LoadScene("EmojiPuzzle");
    }
}
