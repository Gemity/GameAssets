using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LosePopup : MonoBehaviour
{
    public void Next()
    {
        SceneManager.LoadScene("EmojiPuzzle", LoadSceneMode.Single);
    }
}
