using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameControl : MonoBehaviour
{
    private IMiniGame _miniGame;

    void Start()
    {
        LevelData levelData = 
            Resources.Load<LevelData>($"LevelData/Level_{User.LevelId}");

        if(levelData.GameType == GameType.DragShadow)
        {
            DragShadowGame prefab = Resources.Load<DragShadowGame>("DragShadow");
            _miniGame = Instantiate(prefab);
            _miniGame.Init(levelData);
        }
        else if (levelData.GameType == GameType.Match2)
        {
            Match2Game prefab = Resources.Load<Match2Game>("Match2");
            _miniGame = Instantiate(prefab);
            _miniGame.Init(levelData);
        }

        if(_miniGame != null)
        {
            _miniGame.onWin += Win;
            _miniGame.onLose += Lose;
        }
    }

    private void Win()
    {
        User.LevelId++;
        SceneManager.LoadScene("WinPopup", LoadSceneMode.Additive);
    }

    private void Lose()
    {
        SceneManager.LoadScene("LosePopup", LoadSceneMode.Additive);
    }
}
