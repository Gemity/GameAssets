using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class MainControl : MonoBehaviour
{
    [SerializeField] private Image _slideHandle;
    [SerializeField] private float _duration;

    private IEnumerator Start()
    {
        float valua = 0;
        while(valua < 1)
        {
            valua += Time.deltaTime / _duration;
            _slideHandle.fillAmount = valua;

            yield return null;
        }

        SceneManager.LoadScene("EmojiPuzzle", LoadSceneMode.Single);
    }
}
