﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// chứa dữ liệu
public class UserData
{
    public int LevelId;
    public float Percent;

    public void Init()
    {
        LevelId = 1;
        Percent = 0;
    }
}


// xử lý thông tin
public static class User
{
    static UserData data;

    public static int LevelId
    {
        get => data.LevelId;
        set => data.LevelId = value;
    }

    // contructor của class.
    // Được gọi 1 lần duy nhất khi có truy cập đến class
    static User()
    {
        Load();
    }

    private static void Load()
    {
        string json = PlayerPrefs.GetString("UserData", string.Empty);
        if (string.IsNullOrEmpty(json))
        {
            data = new();
            data.Init();
        }
        else
        {
            data = JsonUtility.FromJson<UserData>(json);
        }
    }

    public static void Save()
    {
        string json = JsonUtility.ToJson(data);
        PlayerPrefs.SetString("UserData", json);
    }
}
